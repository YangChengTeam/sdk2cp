package com.sdk.groupsdk;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.feiyou.groupsdk.core.FYGameSDK;
import com.feiyou.groupsdk.core.FYInitCallback;
import com.feiyou.groupsdk.core.FYLoginCallback;
import com.feiyou.groupsdk.core.FYPayCallback;
import com.feiyou.groupsdk.core.FYPayInfo;
import com.feiyou.groupsdk.core.FYResultInfo;
import com.feiyou.groupsdk.core.FYUserInfo;
import com.feiyou.groupsdk.core.Md5;

import com.ipaynow.plugin.log.LogUtils;

public class MainActivity extends Activity {

	private Button mLoginBtn;
	private Button mPayBtn;
	private String userId;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		mLoginBtn = (Button) findViewById(R.id.button);
		mPayBtn = (Button) findViewById(R.id.button2);
		Button exitBtn = (Button) findViewById(R.id.button3);

		Log.e("TAG", FYGameSDK.defaultSDK().getVersion());

		FYGameSDK.defaultSDK().initSDK(this, new FYInitCallback() {

			@Override
			public void switchUser() {
				Toast.makeText(MainActivity.this, "切换用户", Toast.LENGTH_SHORT)
						.show();
			}

			@Override
			public void logout() {
				Toast.makeText(MainActivity.this, "退出登录", Toast.LENGTH_SHORT)
						.show();
				Log.e("TAG", "logout");
			}

			@Override
			public void initSuccess() {
				Log.e("TAG", "initSuccess");

			}

			@Override
			public void initFailure() {
				Log.e("TAG", "initFailure");
			}
		});



		mLoginBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {

				FYGameSDK.defaultSDK().login(MainActivity.this,
						new FYLoginCallback() {

							@Override
							public void loginSuccess(FYUserInfo userInfo) {
								userId = userInfo.getUserid();

								Log.e("TAG", userInfo.getUserid() + "--"
										+ userInfo.getTimestamp());
								FYGameSDK.defaultSDK().showFloatButton();

							}

							@Override
							public void loginFailure(FYResultInfo errorInfo) {

							}
						});
			}
		});

		mPayBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (TextUtils.isEmpty(userId)) {
					Toast.makeText(MainActivity.this, "小子，要先登录哦",
							Toast.LENGTH_SHORT).show();
					return;

				}

				// {"user_id":37,"app_id":5,"title":"%E6%B8%B8%E6%88%8F%E5%85%85%E5%80%BC","attach":"OS5a3b13f417dde","money":9359,"server":"%E6%B5%8B%E8%AF%95%E6%9C%8D%E5%8A%A1%E5%99%A8","role":"%E6%B5%8B%E8%AF%95%E8%A7%92%E8%89%B2","level":50,"ip":"127.0.0.1","sign":"abbdeb2f8aa4380a0c979fbe5d866742"}
				// FYPayInfo payInfo = new FYPayInfo();
				// payInfo.setUserId("86605");
				// payInfo.setAppId(20);
				// payInfo.setOrderMoney(600);
				// payInfo.setServerId("xiongtubaye");
				// payInfo.setAttach("1552320967416479744");
				// payInfo.setIp("120.236.179.45");
				// payInfo.setRole("cdcdd");
				// payInfo.setSign("993ea27afd3214b1e7c340774f0d9388");
				// payInfo.setProductName("test");
				// payInfo.setLevel("1");
				// payInfo.setSdkPay(false);
				FYGameSDK.defaultSDK().pay(MainActivity.this,
						generatePayInfo(), new FYPayCallback() {

							@Override
							public void paySuccess(FYResultInfo resultInfo) {

								Log.e("TAG", (Float) resultInfo.getData() + "");

							}

							@Override
							public void payFailure(FYResultInfo resultInfo) {
								// Log.e("TAG", resultInfo.getMsg());

							}

							@Override
							public void payCancel(FYResultInfo resultInfo) {
								Log.e("TAG", "cancel");
							}
						});

			}
		});

		exitBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// FYGameSDK.defaultSDK().exitSDK();//回调到初始化的logout接口
				FYGameSDK.defaultSDK().openLogout();
			}
		});

	}

	@Override
	protected void onResume() {
		super.onResume();
		FYGameSDK.defaultSDK().showFloatButton();

	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		FYGameSDK.defaultSDK().exitSDK();
	}

	private FYPayInfo generatePayInfo() {
		FYPayInfo fyPayInfo = new FYPayInfo();

		ApplicationInfo info;
		try {
			info = getPackageManager().getApplicationInfo(getPackageName(),
					PackageManager.GET_META_DATA);

			int appid =info.metaData.getInt("GROUP_APPID");
			String attach = System.currentTimeMillis() + "";
			String money ="600";
			String title= "test";
			String server= "xiongtubaye";
			String role ="cdcdd";
			String level= "1";
			String ip ="127.0.0.1";
			String app_key="b71f0f10edde7e256b1c0e187b25a5e4";//这个值改下就行了
			Map<String, String> params = new HashMap<String, String>();
			params.put("user_id", userId);
			params.put("app_id", appid + "");
			params.put("title", title);
			params.put("attach", attach);
			params.put("money", money);
			params.put("server", server);
			params.put("role", role);
			params.put("level", level);
			params.put("ip", ip);
			params.put("app_key", app_key);

			List<Map.Entry<String, String>> list = new ArrayList<Map.Entry<String, String>>(
					params.entrySet());
			Collections.sort(list, new Comparator<Map.Entry<String, String>>() {

				@Override
				public int compare(Entry<String, String> lhs,
						Entry<String, String> rhs) {
					return lhs.getKey().compareTo(rhs.getKey());
				}

			});
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < list.size(); i++) {
				Entry<String, String> entry = list.get(i);
				sb.append(entry.getKey()).append("=").append(entry.getValue())
						.append("&");
				if (i == list.size() - 1) {
					sb.deleteCharAt(sb.length() - 1);
				}
			}
	
			fyPayInfo.setAppId(info.metaData.getInt("GROUP_APPID") );
			fyPayInfo.setAttach(attach);
			fyPayInfo.setIp(ip);
			fyPayInfo.setLevel(level);
			fyPayInfo.setOrderMoney(600);
			fyPayInfo.setUserId(userId);
			fyPayInfo.setServerId(server);
			fyPayInfo.setRole(role);
			fyPayInfo.setSign(Md5.md5(sb.toString()).toLowerCase());
			fyPayInfo.setProductName(title);

		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		return fyPayInfo;

	}

}
