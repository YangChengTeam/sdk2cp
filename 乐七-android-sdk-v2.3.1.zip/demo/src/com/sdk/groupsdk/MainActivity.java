package com.sdk.groupsdk;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import com.feiyou.groupsdk.core.FYGameSDK;
import com.feiyou.groupsdk.core.FYInitCallback;
import com.feiyou.groupsdk.core.FYLoginCallback;
import com.feiyou.groupsdk.core.FYPayCallback;
import com.feiyou.groupsdk.core.FYPayInfo;
import com.feiyou.groupsdk.core.FYResultInfo;
import com.feiyou.groupsdk.core.FYUserInfo;

public class MainActivity extends Activity {

	private Button mLoginBtn;
	private Button mPayBtn;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		mLoginBtn = (Button) findViewById(R.id.button);
		mPayBtn = (Button) findViewById(R.id.button2);
		Button exitBtn=(Button) findViewById(R.id.button3);
		
		Log.e("TAG",FYGameSDK.defaultSDK().getVersion());

		FYGameSDK.defaultSDK().initSDK(this, new FYInitCallback() {

			@Override
			public void switchUser() {
				Toast.makeText(MainActivity.this, "切换用户", Toast.LENGTH_SHORT)
						.show();
			}

			@Override
			public void logout() {
				Toast.makeText(MainActivity.this, "退出登录", Toast.LENGTH_SHORT)
						.show();
				Log.e("TAG", "logout");
			}

			@Override
			public void initSuccess() {
				Log.e("TAG", "initSuccess");

			}

			@Override
			public void initFailure() {
				Log.e("TAG", "initFailure");
			}
		});

		mLoginBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {

				FYGameSDK.defaultSDK().login(MainActivity.this,
						new FYLoginCallback() {

							@Override
							public void loginSuccess(FYUserInfo userInfo) {
								Log.e("TAG", userInfo.getUserid() + "--"
										+ userInfo.getTimestamp());
								FYGameSDK.defaultSDK().showFloatButton();

							}

							@Override
							public void loginFailure(FYResultInfo errorInfo) {

							}
						});
			}
		});

		mPayBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				
				// {"user_id":37,"app_id":5,"title":"%E6%B8%B8%E6%88%8F%E5%85%85%E5%80%BC","attach":"OS5a3b13f417dde","money":9359,"server":"%E6%B5%8B%E8%AF%95%E6%9C%8D%E5%8A%A1%E5%99%A8","role":"%E6%B5%8B%E8%AF%95%E8%A7%92%E8%89%B2","level":50,"ip":"127.0.0.1","sign":"abbdeb2f8aa4380a0c979fbe5d866742"}
				FYPayInfo payInfo = new FYPayInfo();
				payInfo.setUserId("208");
				payInfo.setAppId(2);
				payInfo.setOrderMoney(858);
				payInfo.setServerId("%E6%B5%8B%E8%AF%95%E6%9C%8D%E5%8A%A1%E5%99%A8");
				payInfo.setAttach("OS5a587464aa932");
				payInfo.setIp("127.0.0.1");
				payInfo.setRole("%E6%B5%8B%E8%AF%95%E8%A7%92%E8%89%B2");
				payInfo.setSign("a67375a5af5e5b25443ca85c9e7fe9f8");
				payInfo.setProductName("%E6%B8%B8%E6%88%8F%E5%85%85%E5%80%BC");
				payInfo.setLevel("50");
//				payInfo.setSdkPay(false);
				FYGameSDK.defaultSDK().pay(MainActivity.this, payInfo,
						new FYPayCallback() {

							@Override
							public void paySuccess(FYResultInfo resultInfo) {

								Log.e("TAG", (Float) resultInfo.getData() + "");

							}

							@Override
							public void payFailure(FYResultInfo resultInfo) {
								// Log.e("TAG", resultInfo.getMsg());

							}

							@Override
							public void payCancel(FYResultInfo resultInfo) {
								Log.e("TAG", "cancel");
							}
						});

			}
		});
		
		exitBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
//				FYGameSDK.defaultSDK().exitSDK();//回调到初始化的logout接口
				FYGameSDK.defaultSDK().openLogout();
			}
		});

	}

	@Override
	protected void onResume() {
		super.onResume();
		FYGameSDK.defaultSDK().showFloatButton();

	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		FYGameSDK.defaultSDK().exitSDK();
	}
}
